#include <cstdlib>
#include <ctime>

int main(){
	srand(time(NULL));
	int roll = rand()%100;
	return 0;
}